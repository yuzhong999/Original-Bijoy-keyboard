# Google AI Studio – Bijoy Gboard project analysis prompt

I am providing reference resources extracted from an existing Bijoy Android keyboard APK. Treat them as technical reference material, not as source code to copy.

Before implementing anything:
1. Inspect every readable XML file and resource I provide.
2. If any XML is still Android binary XML, tell me which files need decoding with APKTool. Do not guess their contents.
3. Identify the Bengali key arrangement, output values, shift behavior, symbol layers, popup/long-press mappings, and special key behavior.
4. Create a complete key-by-key mapping table with columns: layout, key position, visible label, output text/code point, shift output, notes.
5. Identify what cannot be established from resources alone and what needs runtime testing.
6. Do not invent missing Bijoy mappings. Mark unknown entries as UNKNOWN.
7. Then propose a native Android implementation using Kotlin and Android InputMethodService, with separate Bengali Bijoy and English QWERTY engines.
8. Implement actual external USB/Bluetooth keyboard handling, including modifier keys, and allow a Bijoy physical-keyboard mapping mode.
9. Build an original, polished, Gboard-inspired UI without Google's trademarks or proprietary assets.
10. Keep all typed text local; do not collect or transmit user input.

Do not start generating the whole application until you have presented the mapping analysis and architecture for review.
