# Bijoy Android Keyboard – Reference Ingredients

This package was extracted from the APK you uploaded:
`Bijoy+Android+Keyboard+বিজয়+এন্ড্রয়েড_3.0_APKPure.apk`

## What is included

- `original_resources/res/xml/` – original keyboard layouts and related XML resources.
- `original_resources/res/xml-land/` – landscape keyboard layouts.
- `original_resources/res/layout/` and `res/layout-land/` – keyboard view layout resources.
- `original_resources/res/drawable*/` – original keyboard graphics and icons.
- `original_resources/assets/Font/` – font asset(s), including AnandaMJ-Regular.ttf if present.
- `original_resources/AndroidManifest.xml` – compiled Android manifest.
- `classes.dex` – original Dalvik bytecode (not human-readable source code).
- `classes_dex_strings.txt` – printable strings extracted from the DEX file; this is not a decompilation.

## Important limitation

The XML files inside an APK are normally Android **binary XML**, not plain text XML. They are preserved here as original resources. Google AI Studio may not understand those binary files as source text.

To convert them into readable XML on Windows, install APKTool and run:

```bash
apktool d "Bijoy.apk" -o "Bijoy_Decoded"
```

Then provide the decoded text files from:
- `res/xml/bangla.xml`
- `res/xml/bangla_shift.xml`
- `res/xml/qwerty.xml`
- `res/xml/bangla_num_symbols.xml`
- `res/xml/bangla_num_shift_symbols.xml`
- `res/xml/shar_borno.xml`
- `res/xml/signs.xml`
- `res/xml/*_jukta_borno.xml`
- `res/layout/keyboard.xml`
- `res/layout-land/keyboard.xml`
- `res/xml/method.xml`

The package does **not** claim to contain recovered original Kotlin/Java source. `classes.dex` is compiled bytecode; use JADX to inspect/decompile it.

## Recommended use with Google AI Studio

Upload the decoded plain-text XML files, the PNG assets, and the font only if its license permits reuse. Ask the model to analyze the layout and mappings before generating a new Android IME.

Do not instruct the model to copy Google's proprietary Gboard code or branding. Build an original Gboard-inspired interface and independently implement the Bijoy-compatible mapping.
